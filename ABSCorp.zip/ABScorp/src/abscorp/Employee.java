/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abscorp;

/**
 *
 * @author muzammil
 */
public class Employee {
    
    public static  int empID;
    public static String username;
    public static String pass;
    public static int salary;
    public static String Satus;
    
}
